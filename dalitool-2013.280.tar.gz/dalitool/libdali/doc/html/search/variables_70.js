var searchData=
[
  ['pktid',['pktid',['../struct_d_l_c_p__s.html#a8fe445744fce413dad18cba20327f9cc',1,'DLCP_s::pktid()'],['../struct_d_l_packet__s.html#a99c262beabe3efa745dbb14a20759f94',1,'DLPacket_s::pktid()']]],
  ['pkttime',['pkttime',['../struct_d_l_c_p__s.html#a2fad3eb1b3143340c30c84e687d04e06',1,'DLCP_s::pkttime()'],['../struct_d_l_packet__s.html#ae201419f715973724eade76770da8b9d',1,'DLPacket_s::pkttime()']]]
];
