var searchData=
[
  ['errprefix',['errprefix',['../struct_d_l_log__s.html#ab0402982f563232c530f1e81dbc7c1ea',1,'DLLog_s']]]
];
