var searchData=
[
  ['verbosity',['verbosity',['../struct_d_l_log__s.html#a2e060eeb368379802727bf853edbf203',1,'DLLog_s']]]
];
