var searchData=
[
  ['maxpktsize',['maxpktsize',['../struct_d_l_c_p__s.html#a2738400592b67f12dadbab739ffd5131',1,'DLCP_s']]]
];
