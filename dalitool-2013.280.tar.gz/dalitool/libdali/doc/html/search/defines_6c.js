var searchData=
[
  ['libdali_5fposition_5fearliest',['LIBDALI_POSITION_EARLIEST',['../libdali_8h.html#a2254fd0fa8be81f2f638c213849fa46c',1,'libdali.h']]],
  ['libdali_5fposition_5flatest',['LIBDALI_POSITION_LATEST',['../libdali_8h.html#a9035d11f02078ef1bb018c446e2cfc7b',1,'libdali.h']]],
  ['libdali_5frelease',['LIBDALI_RELEASE',['../libdali_8h.html#a4c4248807e666b15e1409de320004473',1,'libdali.h']]],
  ['libdali_5fversion',['LIBDALI_VERSION',['../libdali_8h.html#a49a8353fb453d2cf19eb64f6a2570b3c',1,'libdali.h']]]
];
