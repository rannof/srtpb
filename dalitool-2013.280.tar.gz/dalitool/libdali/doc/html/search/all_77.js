var searchData=
[
  ['writeperm',['writeperm',['../struct_d_l_c_p__s.html#a18cd915f9afa5a6b6add7c939d0a1b58',1,'DLCP_s']]]
];
