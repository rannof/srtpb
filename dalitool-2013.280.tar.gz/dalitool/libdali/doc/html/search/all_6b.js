var searchData=
[
  ['keepalive',['keepalive',['../struct_d_l_c_p__s.html#a18b17b1a0c656eea9469e934746c9049',1,'DLCP_s']]],
  ['keepalive_5ftime',['keepalive_time',['../struct_d_l_c_p__s.html#a30517427d868512d3d5cf99c32322100',1,'DLCP_s']]],
  ['keepalive_5ftrig',['keepalive_trig',['../struct_d_l_c_p__s.html#ad168b0d3f2a67ae0bf6f73558061b7ef',1,'DLCP_s']]]
];
