var searchData=
[
  ['libdali_3a_20the_20datalink_20client_20library',['libdali: the DataLink client library',['../index.html',1,'']]]
];
