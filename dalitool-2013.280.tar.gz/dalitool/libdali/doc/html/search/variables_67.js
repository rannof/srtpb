var searchData=
[
  ['gdllog',['gDLLog',['../logging_8c.html#ad92f0f936737fe1a73fc558f3e4b2d63',1,'logging.c']]]
];
